mknod /dev/dram c 85 0
./fileview /dev/dram

